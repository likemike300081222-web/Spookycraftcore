package de.craftsucht.core.markt;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class MarktHolder implements InventoryHolder {
    private final Type type;
    private final String categoryKey;

    public MarktHolder(Type type, String categoryKey) {
        this.type = type;
        this.categoryKey = categoryKey;
    }

    public Type getType() {
        return type;
    }

    public String getCategoryKey() {
        return categoryKey;
    }

    @Override
    public Inventory getInventory() {
        return null;
    }

    public enum Type {
        MAIN,
        CATEGORY
    }
}
