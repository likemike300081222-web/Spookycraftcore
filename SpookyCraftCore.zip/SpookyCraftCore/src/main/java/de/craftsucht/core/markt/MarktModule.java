package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

/**
 * /markt - GUI-Shop mit konfigurierbaren Kategorien (shop.yml). Vorher ein
 * eigenständiges Plugin (MarktPlugin, Vault-basiert), jetzt Modul hier -
 * nutzt für Kauf/Verkauf unsere eigene Economy statt Vault (siehe GuiListener).
 */
public class MarktModule implements Module, CommandExecutor {

    private final SpookyCraftCore plugin;
    private ShopManager shopManager;
    private GuiListener guiListener;

    public MarktModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "markt";
    }

    @Override
    public void enable() {
        this.shopManager = new ShopManager(plugin);
        shopManager.load();
        this.guiListener = new GuiListener(plugin);
        Bukkit.getPluginManager().registerEvents(guiListener, plugin);
        plugin.getCommand("markt").setExecutor(this);
    }

    @Override
    public void disable() {
        if (guiListener != null) HandlerList.unregisterAll(guiListener);
    }

    public ShopManager getShopManager() {
        return shopManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageUtil().send(sender, "&cNur Spieler können den Markt öffnen.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!player.isOp() && !player.hasPermission("craftsucht.core.admin")) {
                plugin.getMessageUtil().send(player, "&cKeine Berechtigung.");
                return true;
            }
            shopManager.load();
            plugin.getMessageUtil().send(player, "&aMarkt neu geladen.");
            return true;
        }
        GuiManager.openMainMenu(player, shopManager);
        return true;
    }
}
