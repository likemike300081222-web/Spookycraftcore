package de.craftsucht.core.nav;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * /nav <welt> und /server <welt> - schneller Weltenwechsel zwischen den
 * Multiverse-Welten. Frei für alle Spieler nutzbar, keine Permission.
 * Tab-Completer schlägt die tatsächlich existierenden Weltnamen vor.
 */
public class NavModule implements Module, CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;

    public NavModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "nav";
    }

    @Override
    public void enable() {
        for (String cmd : new String[]{"nav", "server"}) {
            plugin.getCommand(cmd).setExecutor(this);
            plugin.getCommand(cmd).setTabCompleter(this);
        }
    }

    @Override
    public void disable() {
        // stateless, nichts aufzuräumen
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageUtil().send(sender, "&cDieser Befehl kann nur von Spielern genutzt werden.");
            return true;
        }

        if (args.length < 1) {
            plugin.getMessageUtil().send(player, "&cNutzung: /" + label + " <welt>");
            listWorlds(player);
            return true;
        }

        World target = Bukkit.getWorld(args[0]);
        if (target == null) {
            // Groß-/Kleinschreibung tolerant versuchen zu finden
            for (World w : Bukkit.getWorlds()) {
                if (w.getName().equalsIgnoreCase(args[0])) {
                    target = w;
                    break;
                }
            }
        }

        if (target == null) {
            plugin.getMessageUtil().send(player, "&cWelt &f" + args[0] + " &cnicht gefunden.");
            listWorlds(player);
            return true;
        }

        if (target.equals(player.getWorld())) {
            plugin.getMessageUtil().send(player, "&eDu bist bereits in dieser Welt.");
            return true;
        }

        Location spawn = target.getSpawnLocation();
        player.teleport(spawn);
        plugin.getMessageUtil().send(player, "&aWillkommen in &f" + target.getName() + "&a.");
        return true;
    }

    private void listWorlds(Player player) {
        StringBuilder sb = new StringBuilder();
        for (World w : Bukkit.getWorlds()) {
            if (sb.length() > 0) sb.append("&7, &f");
            sb.append(w.getName());
        }
        plugin.getMessageUtil().send(player, "&7Verfügbare Welten: &f" + sb);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) {
            return Collections.emptyList();
        }
        String partial = args[0].toLowerCase();
        List<String> names = new ArrayList<>();
        for (World w : Bukkit.getWorlds()) {
            if (w.getName().toLowerCase().startsWith(partial)) {
                names.add(w.getName());
            }
        }
        return names;
    }
}
