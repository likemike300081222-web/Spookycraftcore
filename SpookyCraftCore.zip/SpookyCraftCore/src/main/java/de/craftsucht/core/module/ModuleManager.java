package de.craftsucht.core.module;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.punish.PunishModule;
import de.craftsucht.core.essentials.EssentialsModule;
import de.craftsucht.core.nickname.NicknameModule;
import de.craftsucht.core.friends.FriendsModule;
import de.craftsucht.core.clan.ClanModule;
import de.craftsucht.core.vanish.VanishModule;
import de.craftsucht.core.stats.StatsModule;
import de.craftsucht.core.scoreboard.ScoreboardModule;
import de.craftsucht.core.tablist.TabListModule;
import de.craftsucht.core.kits.KitsModule;
import de.craftsucht.core.shop.AuctionModule;
import de.craftsucht.core.report.ReportModule;
import de.craftsucht.core.discord.DiscordModule;
import de.craftsucht.core.party.PartyModule;
import de.craftsucht.core.anticheat.AntiCheatModule;
import de.craftsucht.core.maintenance.MaintenanceModule;
import de.craftsucht.core.rank.RankModule;
import de.craftsucht.core.util.UtilityModule;
import de.craftsucht.core.alert.AlertModule;
import de.craftsucht.core.itemdb.ItemDbModule;
import de.craftsucht.core.nav.NavModule;
import de.craftsucht.core.markt.MarktModule;
import de.craftsucht.core.jobs.JobsModule;
import de.craftsucht.core.booster.BoosterModule;
import de.craftsucht.core.bank.BankModule;
import de.craftsucht.core.staffchat.StaffChatModule;
import org.bukkit.command.CommandSender;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModuleManager {

    private final SpookyCraftCore plugin;
    private final Map<String, Module> modules = new LinkedHashMap<>();
    private final Map<String, Boolean> enabledState = new LinkedHashMap<>();

    public ModuleManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void registerAll() {
        register(new RankModule(plugin));
        register(new EconomyModule(plugin));
        register(new PunishModule(plugin));
        register(new EssentialsModule(plugin));
        register(new NicknameModule(plugin));
        register(new FriendsModule(plugin));
        register(new ClanModule(plugin));
        register(new VanishModule(plugin));
        register(new StatsModule(plugin));
        register(new ScoreboardModule(plugin));
        register(new TabListModule(plugin));
        register(new KitsModule(plugin));
        register(new AuctionModule(plugin));
        register(new ReportModule(plugin));
        register(new DiscordModule(plugin));
        register(new PartyModule(plugin));
        register(new AntiCheatModule(plugin));
        register(new MaintenanceModule(plugin));
        register(new UtilityModule(plugin));
        register(new AlertModule(plugin));
        register(new ItemDbModule(plugin));
        register(new NavModule(plugin));
        register(new MarktModule(plugin));
        register(new JobsModule(plugin));
        register(new BoosterModule(plugin));
        register(new BankModule(plugin));
        register(new StaffChatModule(plugin));
    }

    private void register(Module module) {
        modules.put(module.getId(), module);
    }

    public void enableEnabled() {
        for (Module module : modules.values()) {
            boolean on = plugin.getConfig().getBoolean("modules." + module.getId(), true);
            enabledState.put(module.getId(), on);
            if (on) {
                try {
                    module.enable();
                } catch (Exception e) {
                    plugin.getLogger().warning("Modul '" + module.getId() + "' konnte nicht aktiviert werden: " + e.getMessage());
                }
            }
        }
    }

    public void disableAll() {
        for (Module module : modules.values()) {
            if (Boolean.TRUE.equals(enabledState.get(module.getId()))) {
                try {
                    module.disable();
                } catch (Exception ignored) {
                }
            }
        }
    }

    public void reloadAll() {
        disableAll();
        enableEnabled();
    }

    public Module get(String id) {
        return modules.get(id);
    }

    public int getEnabledCount() {
        return (int) enabledState.values().stream().filter(Boolean::booleanValue).count();
    }

    public void listModules(CommandSender sender) {
        sender.sendMessage("§7--- §6SpookyCraft§7 Module ---");
        modules.forEach((id, module) -> {
            boolean on = enabledState.getOrDefault(id, false);
            sender.sendMessage((on ? "§a● " : "§c● ") + id);
        });
    }
}
