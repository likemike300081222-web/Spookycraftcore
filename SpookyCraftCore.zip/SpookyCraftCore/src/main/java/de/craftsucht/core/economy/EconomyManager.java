package de.craftsucht.core.economy;

import de.craftsucht.core.SpookyCraftCore;

import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class EconomyManager {

    private final SpookyCraftCore plugin;
    private final double startingBalance;

    public EconomyManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.startingBalance = plugin.getConfig().getDouble("economy.starting-balance", 100.0);
    }

    public double getBalance(UUID uuid) {
        String sql = "SELECT balance FROM economy WHERE uuid = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("balance");
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Economy getBalance fehlgeschlagen: " + e.getMessage());
        }
        setBalance(uuid, startingBalance);
        return startingBalance;
    }

    public void setBalance(UUID uuid, double amount) {
        String sql = "INSERT INTO economy (uuid, balance) VALUES (?, ?) " +
                "ON CONFLICT(uuid) DO UPDATE SET balance = excluded.balance";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setDouble(2, amount);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Economy setBalance fehlgeschlagen: " + e.getMessage());
        }
    }

    public boolean withdraw(UUID uuid, double amount) {
        double bal = getBalance(uuid);
        if (bal < amount) return false;
        setBalance(uuid, bal - amount);
        return true;
    }

    public void deposit(UUID uuid, double amount) {
        setBalance(uuid, getBalance(uuid) + amount);
    }

    public Map<String, Double> getTop(int limit) {
        Map<String, Double> result = new LinkedHashMap<>();
        String sql = "SELECT uuid, balance FROM economy ORDER BY balance DESC LIMIT ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String name = plugin.getServer().getOfflinePlayer(UUID.fromString(rs.getString("uuid"))).getName();
                    result.put(name != null ? name : rs.getString("uuid"), rs.getDouble("balance"));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Economy getTop fehlgeschlagen: " + e.getMessage());
        }
        return result;
    }
}
