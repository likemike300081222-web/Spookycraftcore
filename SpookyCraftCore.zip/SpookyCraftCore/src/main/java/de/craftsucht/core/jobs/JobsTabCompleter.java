package de.craftsucht.core.jobs;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.List;

public class JobsTabCompleter implements TabCompleter {
    private static final List<String> SUB_COMMANDS = List.of("info", "reload");
    private final JobsModule jobs;

    public JobsTabCompleter(JobsModule jobs) { this.jobs = jobs; }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<>();
        if (!(sender instanceof Player)) return completions;
        if (args.length == 1) {
            StringUtil.copyPartialMatches(args[0], SUB_COMMANDS, completions);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("info")) {
            StringUtil.copyPartialMatches(args[1], jobs.getJobManager().getAvailableJobs(), completions);
        }
        return completions;
    }
}
