package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ItemRegistry {

    /** Erlaubter Bereich für den Booster-Prozentsatz, siehe build() mit Override. */
    public static final double MIN_PERCENT = 10.0;
    public static final double MAX_PERCENT = 1000.0;

    private final SpookyCraftCore plugin;
    private final Map<String, ItemTemplate> templates = new LinkedHashMap<>();

    public ItemRegistry(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void load() {
        templates.clear();
        File file = new File(plugin.getDataFolder(), "items.yml");
        if (!file.exists()) {
            plugin.saveResource("items.yml", false);
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection itemsSection = yaml.getConfigurationSection("items");
        if (itemsSection == null) {
            plugin.getLogger().warning("items.yml enthält keinen 'items:' Abschnitt.");
            return;
        }
        for (String id : itemsSection.getKeys(false)) {
            ConfigurationSection section = itemsSection.getConfigurationSection(id);
            if (section == null) continue;
            try {
                ItemTemplate template = parseTemplate(id, section);
                templates.put(id.toLowerCase(), template);
            } catch (Exception e) {
                plugin.getLogger().warning("Konnte Item '" + id + "' nicht laden: " + e.getMessage());
            }
        }
    }

    private ItemTemplate parseTemplate(String id, ConfigurationSection section) {
        Material material = Material.matchMaterial(section.getString("material", "STONE"));
        if (material == null) material = Material.STONE;
        String displayName = section.getString("display-name", "&fCustom Item");
        boolean unbreakable = section.getBoolean("unbreakable", false);
        boolean glow = section.getBoolean("glow", false);
        Map<String, Integer> enchants = new LinkedHashMap<>();
        ConfigurationSection enchSection = section.getConfigurationSection("enchants");
        if (enchSection != null) {
            for (String key : enchSection.getKeys(false)) {
                enchants.put(key.toUpperCase(), enchSection.getInt(key));
            }
        }
        List<String> lore = section.getStringList("lore");
        String boosterJob = null;
        double moneyPercent = 0.0;
        double xpPercent = 0.0;
        ConfigurationSection boosterSection = section.getConfigurationSection("booster");
        if (boosterSection != null) {
            boosterJob = boosterSection.getString("job");
            moneyPercent = boosterSection.getDouble("money-percent", 0.0);
            xpPercent = boosterSection.getDouble("xp-percent", 0.0);
        }
        return new ItemTemplate(id, material, displayName, unbreakable, glow, enchants, lore, boosterJob, moneyPercent, xpPercent);
    }

    public ItemStack build(ItemTemplate template) {
        return build(template, null);
    }

    /**
     * Baut das Item wie im Original, aber mit optionalem Prozent-Override
     * für Geld/XP (z.B. per /citem give <spieler> <id> <prozent>) - geklemmt
     * auf MIN_PERCENT-MAX_PERCENT (10-1000%). null = Standardwert aus items.yml.
     */
    public ItemStack build(ItemTemplate template, Double percentOverride) {
        double money = template.getBoosterMoneyPercent();
        double xp = template.getBoosterXpPercent();
        if (percentOverride != null) {
            double clamped = Math.max(MIN_PERCENT, Math.min(MAX_PERCENT, percentOverride));
            money = clamped;
            xp = clamped;
        }

        ItemStack item = new ItemStack(template.getMaterial());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color(template.getDisplayName()));
        meta.setUnbreakable(template.isUnbreakable());
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);

        for (Map.Entry<String, Integer> entry : template.getEnchants().entrySet()) {
            Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(entry.getKey().toLowerCase()));
            if (enchantment == null) {
                plugin.getLogger().warning("Unbekanntes Enchantment: " + entry.getKey());
                continue;
            }
            meta.addEnchant(enchantment, entry.getValue(), true);
        }
        if (template.isGlow() && template.getEnchants().isEmpty()) {
            Enchantment glowEnchant = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("unbreaking"));
            if (glowEnchant != null) {
                meta.addEnchant(glowEnchant, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }
        }

        List<String> coloredLore = new ArrayList<>();
        for (String line : template.getLore()) {
            String replaced = line.replace("{money}", trimPercent(money)).replace("{xp}", trimPercent(xp));
            coloredLore.add(color(replaced));
        }
        meta.setLore(coloredLore);

        if (template.getBoosterJob() != null) {
            PersistentDataContainer pdc = meta.getPersistentDataContainer();
            pdc.set(BoosterAPI.keyJob(plugin), PersistentDataType.STRING, template.getBoosterJob());
            pdc.set(BoosterAPI.keyMoney(plugin), PersistentDataType.DOUBLE, money);
            pdc.set(BoosterAPI.keyXp(plugin), PersistentDataType.DOUBLE, xp);
        }
        item.setItemMeta(meta);
        return item;
    }

    private String trimPercent(double value) {
        if (value == Math.floor(value)) {
            return String.valueOf((int) value);
        }
        return String.valueOf(value);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public Map<String, ItemTemplate> getTemplates() {
        return templates;
    }

    public ItemTemplate getTemplate(String id) {
        return templates.get(id.toLowerCase());
    }
}
