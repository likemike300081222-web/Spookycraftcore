package de.craftsucht.core.jobs;

import de.craftsucht.core.booster.BoosterAPI;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class JobListener implements Listener {

    private final JobsModule jobs;

    public JobListener(JobsModule jobs) { this.jobs = jobs; }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        jobs.getPlayerDataManager().get(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        jobs.getPlayerDataManager().unload(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) return;
        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());

        // Ein Block kann mehrere Jobs gleichzeitig bedienen (z.B. GRAVEL = Miner + Gräber).
        for (String jobId : jobs.getJobManager().getAvailableJobs()) {
            JobData jd = data.getOrCreateJob(jobId);
            double pay = jobs.getJobManager().getBlockPay(jobId, event.getBlock().getType(), jd);
            if (pay <= 0.0) continue;
            payOut(player, data, jobId, pay);
        }
        jobs.getPlayerDataManager().save(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        Player player = event.getEntity().getKiller();
        if (player == null) return;
        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());
        String jobId = "hunter";
        if (!jobs.getJobManager().isValidJob(jobId)) return;
        JobData jd = data.getOrCreateJob(jobId);
        double pay = jobs.getJobManager().getMobPay(jobId, event.getEntity().getType(), jd);
        if (pay <= 0.0) return;
        payOut(player, data, jobId, pay);
        jobs.getPlayerDataManager().save(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        Player player = event.getPlayer();
        String jobId = "fisher";
        if (!jobs.getJobManager().isValidJob(jobId)) return;
        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());
        String fishType = "JUNK";
        if (event.getCaught() != null) {
            String name = event.getCaught().getType().name();
            if (name.equals("FISHING_ROD") || name.equals("BOW") || name.equals("BOOK")
                    || name.equals("NAME_TAG") || name.equals("SADDLE") || name.equals("NAUTILUS_SHELL")) {
                fishType = "TREASURE";
            } else if (name.equals("COD") || name.equals("SALMON") || name.equals("TROPICAL_FISH") || name.equals("PUFFERFISH")) {
                fishType = name;
            }
        }
        JobData jd = data.getOrCreateJob(jobId);
        double pay = jobs.getJobManager().getFishPay(jobId, fishType, jd);
        if (pay <= 0.0) return;
        payOut(player, data, jobId, pay);
        jobs.getPlayerDataManager().save(player.getUniqueId());
    }

    private void payOut(Player player, PlayerData data, String jobId, double basePay) {
        BoosterAPI.BoosterResult boost = BoosterAPI.getBoost(jobs.plugin, player, jobId);
        int xp = (int) Math.round(jobs.getJobManager().getXpPerAction() * boost.xpMultiplier());
        double finalPay = basePay * boost.moneyMultiplier();
        jobs.getJobManager().pay(player, data, jobId, finalPay);
        jobs.getJobManager().giveXp(player, data, jobId, xp);
    }
}
