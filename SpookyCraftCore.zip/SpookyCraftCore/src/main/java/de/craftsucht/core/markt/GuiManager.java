package de.craftsucht.core.markt;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class GuiManager {

    public static final String MAIN_TITLE = ChatColor.translateAlternateColorCodes('&', "&8&lMarkt");
    public static final String CATEGORY_PREFIX = ChatColor.translateAlternateColorCodes('&', "&8&lMarkt: &r");

    private GuiManager() {
    }

    public static void openMainMenu(Player player, ShopManager shopManager) {
        Inventory inv = Bukkit.createInventory(new MarktHolder(MarktHolder.Type.MAIN, null), 27, MAIN_TITLE);
        for (ShopCategory category : shopManager.getCategories().values()) {
            ItemStack icon = new ItemStack(category.getIcon());
            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', category.getDisplayName()));
                meta.setLore(List.of(ChatColor.GRAY + "Klicken zum Öffnen"));
                icon.setItemMeta(meta);
            }
            int slot = category.getSlot();
            if (slot < 0 || slot >= inv.getSize()) {
                slot = inv.firstEmpty();
            }
            inv.setItem(slot, icon);
        }
        player.openInventory(inv);
    }

    public static void openCategory(Player player, ShopCategory category) {
        int rows = Math.max(3, (int) Math.ceil(category.getItems().size() / 9.0) + 1);
        rows = Math.min(rows, 6);
        String title = CATEGORY_PREFIX + ChatColor.translateAlternateColorCodes('&', category.getDisplayName());
        Inventory inv = Bukkit.createInventory(new MarktHolder(MarktHolder.Type.CATEGORY, category.getKey()), rows * 9, title);

        int slot = 0;
        for (ShopItem item : category.getItems()) {
            if (slot >= inv.getSize() - 9) break;
            inv.setItem(slot, buildBuyItem(item));
            slot++;
        }

        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName(ChatColor.YELLOW + "Zurück zum Hauptmenü");
            back.setItemMeta(backMeta);
        }
        inv.setItem(inv.getSize() - 5, back);

        ItemStack info = new ItemStack(Material.PAPER);
        ItemMeta infoMeta = info.getItemMeta();
        if (infoMeta != null) {
            infoMeta.setDisplayName(ChatColor.AQUA + "Verkaufen");
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Klicke im Hotbar-Bereich");
            lore.add(ChatColor.GRAY + "auf ein Item in deinem");
            lore.add(ChatColor.GRAY + "eigenen Inventar zum Verkaufen.");
            infoMeta.setLore(lore);
            info.setItemMeta(infoMeta);
        }
        inv.setItem(inv.getSize() - 1, info);

        player.openInventory(inv);
    }

    private static ItemStack buildBuyItem(ShopItem item) {
        ItemStack stack = new ItemStack(item.getMaterial());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.WHITE + formatName(item.getMaterial()));
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GREEN + "Kaufpreis: " + item.getBuyPrice() + "$");
            lore.add(ChatColor.RED + "Verkaufspreis: " + item.getSellPrice() + "$ (pro Stück)");
            lore.add("");
            lore.add(ChatColor.GRAY + "Linksklick: 1 kaufen");
            lore.add(ChatColor.GRAY + "Shift-Linksklick: 64 kaufen");
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private static String formatName(Material material) {
        String[] parts = material.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }
}
