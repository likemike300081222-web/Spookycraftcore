package de.craftsucht.core.itemdb;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

/**
 * Serialisiert ItemStacks (inkl. NBT, Enchantments, Lore, Displayname) als Base64-String,
 * damit sie 1:1 in SQLite gespeichert und wiederhergestellt werden können.
 */
public final class ItemSerializer {

    private ItemSerializer() {
    }

    public static String toBase64(ItemStack item) throws IOException {
        try (ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
             BukkitObjectOutputStream dataOut = new BukkitObjectOutputStream(byteOut)) {
            dataOut.writeObject(item);
            return Base64.getEncoder().encodeToString(byteOut.toByteArray());
        }
    }

    public static ItemStack fromBase64(String data) throws IOException, ClassNotFoundException {
        byte[] bytes = Base64.getDecoder().decode(data);
        try (ByteArrayInputStream byteIn = new ByteArrayInputStream(bytes);
             BukkitObjectInputStream dataIn = new BukkitObjectInputStream(byteIn)) {
            return (ItemStack) dataIn.readObject();
        }
    }
}
