package de.craftsucht.core.stats;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.sql.*;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class StatsModule implements Module, CommandExecutor, TabCompleter, Listener {

    private final SpookyCraftCore plugin;

    public StatsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "stats";
    }

    @Override
    public void enable() {
        plugin.getCommand("stats").setExecutor(this);
        plugin.getCommand("top").setExecutor(this);
        plugin.getCommand("top").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
    }

    private void ensureRow(UUID uuid) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO stats (uuid) VALUES (?)")) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException ignored) {
        }
    }

    private void increment(UUID uuid, String column) {
        ensureRow(uuid);
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE stats SET " + column + " = " + column + " + 1 WHERE uuid=?")) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException ignored) {
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        increment(event.getPlayer().getUniqueId(), "blocks_broken");
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        increment(event.getEntity().getUniqueId(), "deaths");
        Player killer = event.getEntity().getKiller();
        if (killer != null) increment(killer.getUniqueId(), "kills");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("stats")) {
            if (!(sender instanceof Player p)) return true;
            ensureRow(p.getUniqueId());
            try (Connection c = plugin.getDatabase().getConnection();
                 PreparedStatement ps = c.prepareStatement("SELECT blocks_broken, kills, deaths FROM stats WHERE uuid=?")) {
                ps.setString(1, p.getUniqueId().toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        plugin.getMessageUtil().sendRaw(p, "&8--- &bDeine Statistiken &8---");
                        plugin.getMessageUtil().sendRaw(p, "&7Blöcke abgebaut: &b" + rs.getInt("blocks_broken"));
                        plugin.getMessageUtil().sendRaw(p, "&7Kills: &b" + rs.getInt("kills") + " &7Tode: &b" + rs.getInt("deaths"));
                    }
                }
            } catch (SQLException e) {
                plugin.getMessageUtil().send(p, "&cFehler beim Laden.");
            }
            return true;
        }
        if (label.equalsIgnoreCase("top")) {
            String column = args.length > 0 ? args[0] : "kills";
            if (!column.matches("blocks_broken|kills|deaths|playtime_seconds")) {
                plugin.getMessageUtil().send(sender, "&cNutzung: /top <kills|deaths|blocks_broken|playtime_seconds>");
                return true;
            }
            try (Connection c = plugin.getDatabase().getConnection();
                 PreparedStatement ps = c.prepareStatement("SELECT uuid, " + column + " FROM stats ORDER BY " + column + " DESC LIMIT 10")) {
                try (ResultSet rs = ps.executeQuery()) {
                    plugin.getMessageUtil().sendRaw(sender, "&8--- &bTop 10: " + column + " &8---");
                    int i = 1;
                    while (rs.next()) {
                        String name = Bukkit.getOfflinePlayer(UUID.fromString(rs.getString("uuid"))).getName();
                        plugin.getMessageUtil().sendRaw(sender, "&7#" + i++ + " &b" + name + " &7- " + rs.getInt(column));
                    }
                }
            } catch (SQLException e) {
                plugin.getMessageUtil().send(sender, "&cFehler beim Laden.");
            }
            return true;
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return TabCompleteUtil.filter(args[0], "kills", "deaths", "blocks_broken", "playtime_seconds");
        }
        return Collections.emptyList();
    }
}
