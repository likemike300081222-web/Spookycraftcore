package de.craftsucht.core.itemdb;

import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class ItemDbGuiListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory topInventory = event.getView().getTopInventory();
        if (!(topInventory.getHolder() instanceof ItemDbGuiHolder holder)) {
            return;
        }

        // Jeglicher Klick in der DB-GUI selbst wird abgebrochen (nichts entnehmbar,
        // es sei denn itemdb.take erlaubt explizit eine Kopie - siehe unten).
        if (event.getClickedInventory() != null && event.getClickedInventory().equals(topInventory)) {
            event.setCancelled(true);

            int slot = event.getRawSlot();
            HumanEntity clicker = event.getWhoClicked();
            if (!(clicker instanceof Player player)) {
                return;
            }

            if (slot == ItemDbGuiHolder.PREV_SLOT && holder.getPage() > 0) {
                player.openInventory(GuiBuilder.build(holder.getEntries(), holder.getPage() - 1, holder.getTitle()));
                return;
            }
            if (slot == ItemDbGuiHolder.NEXT_SLOT && holder.getPage() < holder.getMaxPage()) {
                player.openInventory(GuiBuilder.build(holder.getEntries(), holder.getPage() + 1, holder.getTitle()));
                return;
            }

            // Klick auf ein echtes Item-Slot (0-44) - mit itemdb.take gibt's eine Kopie.
            if (slot >= 0 && slot < ItemDbGuiHolder.PAGE_SIZE) {
                if (!player.isOp() && !player.hasPermission("itemdb.take")) {
                    return;
                }
                List<DBEntry> entries = holder.getEntries();
                int index = holder.getPage() * ItemDbGuiHolder.PAGE_SIZE + slot;
                if (index < 0 || index >= entries.size()) {
                    return;
                }
                ItemStack copy = entries.get(index).getItem().clone();
                copy.setAmount(1);
                var leftover = player.getInventory().addItem(copy);
                if (leftover.isEmpty()) {
                    player.sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&',
                            "&aKopie von &f" + entries.get(index).getName() + " &aerhalten."));
                } else {
                    player.sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&',
                            "&cInventar voll - Item konnte nicht übergeben werden."));
                }
            }
        } else if (event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT) {
            // Shift-Klick im eigenen Inventar könnte theoretisch versuchen, in die DB-GUI zu wandern -> verhindern
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ItemDbGuiHolder) {
            event.setCancelled(true);
        }
    }
}

