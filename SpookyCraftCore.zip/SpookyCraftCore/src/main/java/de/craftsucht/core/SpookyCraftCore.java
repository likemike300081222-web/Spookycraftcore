package de.craftsucht.core;

import de.craftsucht.core.database.Database;
import de.craftsucht.core.module.ModuleManager;
import de.craftsucht.core.util.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class SpookyCraftCore extends JavaPlugin {

    private static SpookyCraftCore instance;
    private Database database;
    private ModuleManager moduleManager;
    private MessageUtil messageUtil;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.messageUtil = new MessageUtil(this);
        this.database = new Database(this);
        this.database.connect();
        this.database.migrate();

        this.moduleManager = new ModuleManager(this);
        this.moduleManager.registerAll();
        this.moduleManager.enableEnabled();

        getLogger().info("SpookyCraftCore aktiviert - " + moduleManager.getEnabledCount() + " Module geladen.");
    }

    @Override
    public void onDisable() {
        if (moduleManager != null) {
            moduleManager.disableAll();
        }
        if (database != null) {
            database.close();
        }
        getLogger().info("SpookyCraftCore deaktiviert.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("bccore")) {
            if (!sender.isOp() && !sender.hasPermission("craftsucht.core.admin")) {
                messageUtil.send(sender, "&cKeine Berechtigung.");
                return true;
            }
            if (args.length == 0) {
                messageUtil.send(sender, "&7/bccore reload | modules");
                return true;
            }
            if (args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                moduleManager.reloadAll();
                messageUtil.send(sender, "&aSpookyCraftCore neu geladen.");
                return true;
            }
            if (args[0].equalsIgnoreCase("modules")) {
                moduleManager.listModules(sender);
                return true;
            }
        }
        return false;
    }

    public static SpookyCraftCore getInstance() {
        return instance;
    }

    public Database getDatabase() {
        return database;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public MessageUtil getMessageUtil() {
        return messageUtil;
    }
}
