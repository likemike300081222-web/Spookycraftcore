package de.craftsucht.core.jobs;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Alle 10 Level gibt's Items + einen Server-Broadcast mit dem neuen Titel.
 * ACHTUNG: Das Original setzte den Titel zusätzlich als kompletten echten
 * LuckPerms-Prefix. Das haben wir NICHT übernommen (unser RankManager
 * ignoriert LuckPerms-Prefixe grundsätzlich, der Text wäre unsichtbar
 * geblieben). Stattdessen wird NUR die Farbe des höchsten erreichten Titels
 * übernommen und auf den Spielernamen in Chat/Tab/Nametag angewendet (siehe
 * getTierColor() unten, genutzt von RankListener/ScoreboardModule) - der
 * Rang-Prefix selbst (aus /rank) bleibt unverändert, nur die Namensfarbe
 * ändert sich mit dem Job-Fortschritt.
 */
public class RewardManager {

    private final SpookyCraftCore plugin;
    private static final Map<Integer, String> MINER_TITLES = new HashMap<>();
    private static final Map<Integer, String> WOODCUTTER_TITLES = new HashMap<>();
    private static final Map<Integer, String> HUNTER_TITLES = new HashMap<>();
    private static final Map<Integer, String> FISHER_TITLES = new HashMap<>();
    private static final Map<Integer, String> DIGGER_TITLES = new HashMap<>();

    public RewardManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    private static Map<Integer, String> getTitlesForJob(String jobId) {
        return switch (jobId) {
            case "miner" -> MINER_TITLES;
            case "woodcutter" -> WOODCUTTER_TITLES;
            case "hunter" -> HUNTER_TITLES;
            case "fisher" -> FISHER_TITLES;
            case "digger" -> DIGGER_TITLES;
            default -> null;
        };
    }

    public void checkAndGiveReward(Player player, String jobId, int newLevel) {
        if (newLevel % 10 != 0) return;
        giveItems(player, newLevel);
        Map<Integer, String> titles = getTitlesForJob(jobId);
        if (titles != null && titles.containsKey(newLevel)) {
            broadcastReward(player, titles.get(newLevel), newLevel, jobId);
        }
    }

    private void giveItems(Player player, int level) {
        ItemStack reward;
        String itemName;
        int rotation = (level / 10) % 3;
        switch (rotation) {
            case 0 -> {
                reward = buildItem(Material.DIAMOND, 5, "&b✦ Job-Belohnung", "&75x Diamanten für Level &e" + level);
                itemName = "5x Diamanten";
            }
            case 1 -> {
                reward = buildItem(Material.GOLD_INGOT, 8, "&6✦ Job-Belohnung", "&78x Goldbarren für Level &e" + level);
                itemName = "8x Goldbarren";
            }
            default -> {
                reward = buildItem(Material.EMERALD, 6, "&a✦ Job-Belohnung", "&76x Smaragde für Level &e" + level);
                itemName = "6x Smaragde";
            }
        }
        if (player.getInventory().firstEmpty() == -1) {
            player.getWorld().dropItemNaturally(player.getLocation(), reward);
            player.sendMessage(ChatColor.YELLOW + "⚠ Inventar voll! Belohnung wurde gedroppt.");
        } else {
            player.getInventory().addItem(reward);
            player.sendMessage(ChatColor.GREEN + "✦ Belohnung erhalten: §a§l" + itemName);
        }
    }

    private ItemStack buildItem(Material mat, int amount, String name, String lore) {
        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.getMessageUtil().color(name));
            List<String> loreList = new ArrayList<>();
            loreList.add(plugin.getMessageUtil().color(lore));
            loreList.add(ChatColor.GRAY + "Verdient durch harte Arbeit!");
            meta.setLore(loreList);
            item.setItemMeta(meta);
        }
        return item;
    }

    private void broadcastReward(Player player, String title, int level, String jobId) {
        JobsModule jobsModule = (JobsModule) plugin.getModuleManager().get("jobs");
        String jobDisplay = jobsModule.getJobManager().getJobDisplayName(jobId);
        String coloredTitle = plugin.getMessageUtil().color(title);
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            p.sendMessage("");
            p.sendMessage(ChatColor.GOLD + "★═══════════════════════════★");
            p.sendMessage(ChatColor.YELLOW + " 🏆 " + player.getName() + ChatColor.YELLOW + " erreichte Level §6§l" + level + ChatColor.YELLOW + " als " + jobDisplay + "!");
            p.sendMessage(ChatColor.AQUA + " Neuer Titel: " + coloredTitle);
            p.sendMessage(ChatColor.GOLD + "★═══════════════════════════★");
            p.sendMessage("");
        }
    }

    public int getNextRewardLevel(int currentLevel) {
        for (int i = currentLevel + 1; i <= 230; i++) {
            if (i % 10 == 0) return i;
        }
        return -1;
    }

    /**
     * Nur die FARBE des höchsten bereits erreichten Job-Titels (z.B. &6 bei
     * "Bergmann" ab Level 30) - kein ganzer Text/Klammer-Prefix, nur der
     * Farbcode. Wird für die Namensfarbe in Chat/Tab/Nametag verwendet.
     * Gibt null zurück, wenn noch kein Titel-Level erreicht wurde.
     */
    public ChatColor getTierColor(String jobId, int level) {
        Map<Integer, String> titles = getTitlesForJob(jobId);
        if (titles == null) return null;
        ChatColor result = null;
        for (int milestone = 10; milestone <= level; milestone += 10) {
            String raw = titles.get(milestone);
            if (raw == null) continue;
            ChatColor extracted = extractColor(raw);
            if (extracted != null) result = extracted;
        }
        return result;
    }

    /**
     * Titel folgen dem Muster "&7[&X&lName&7] &r" - der erste Farbcode ist
     * immer &7 (die graue Klammer), die eigentliche Titelfarbe X ist der
     * ZWEITE Farbcode im String. Reines "ersten Code nehmen" würde also fast
     * immer Grau liefern statt der individuellen Farbe je Meilenstein.
     */
    private ChatColor extractColor(String raw) {
        ChatColor first = null;
        for (int i = 0; i < raw.length() - 1; i++) {
            if (raw.charAt(i) == '&') {
                ChatColor c = ChatColor.getByChar(raw.charAt(i + 1));
                if (c != null && c.isColor()) {
                    if (first == null) {
                        first = c;
                    } else {
                        return c;
                    }
                }
            }
        }
        return first;
    }

    /** Alle Meilensteine (Level 10-230) für einen Job, mit Titel-Text, Farbe und ob schon erreicht. */
    public List<MilestoneEntry> getMilestones(String jobId, int currentLevel) {
        List<MilestoneEntry> result = new ArrayList<>();
        Map<Integer, String> titles = getTitlesForJob(jobId);
        if (titles == null) return result;
        for (int level = 10; level <= 230; level += 10) {
            String raw = titles.get(level);
            if (raw == null) continue;
            ChatColor color = extractColor(raw);
            result.add(new MilestoneEntry(level, raw, color, currentLevel >= level));
        }
        return result;
    }

    public record MilestoneEntry(int level, String rawTitle, ChatColor color, boolean unlocked) {
    }

    static {
        MINER_TITLES.put(10, "&7[&f&lSteinbrecher&7] &r");
        MINER_TITLES.put(20, "&7[&e&lErzsucher&7] &r");
        MINER_TITLES.put(30, "&7[&6&lBergmann&7] &r");
        MINER_TITLES.put(40, "&7[&a&lHöhlentaucher&7] &r");
        MINER_TITLES.put(50, "&7[&b&lEiskraxler&7] &r");
        MINER_TITLES.put(60, "&7[&d&lFelsspalter&7] &r");
        MINER_TITLES.put(70, "&7[&c&lGesteinsmeister&7] &r");
        MINER_TITLES.put(80, "&7[&4&lTiefengräber&7] &r");
        MINER_TITLES.put(90, "&7[&5&lDunkelkraxler&7] &r");
        MINER_TITLES.put(100, "&7[&6&l✦ Erzkönig&7] &r");
        MINER_TITLES.put(110, "&7[&2&lSchachtmeister&7] &r");
        MINER_TITLES.put(120, "&7[&3&lNetherbrecher&7] &r");
        MINER_TITLES.put(130, "&7[&9&lSteinwächter&7] &r");
        MINER_TITLES.put(140, "&7[&1&lKristallsucher&7] &r");
        MINER_TITLES.put(150, "&7[&e&l★ Bergfürst&7] &r");
        MINER_TITLES.put(160, "&7[&b&lTiefenherrscher&7] &r");
        MINER_TITLES.put(170, "&7[&d&lNethermeister&7] &r");
        MINER_TITLES.put(180, "&7[&6&lLavagänger&7] &r");
        MINER_TITLES.put(190, "&7[&4&lUnterweltkönig&7] &r");
        MINER_TITLES.put(200, "&7[&c&l✦✦ Vulkanmeister&7] &r");
        MINER_TITLES.put(210, "&7[&5&lLegendärer Gräber&7] &r");
        MINER_TITLES.put(220, "&7[&e&l★★ Berglegend&7] &r");
        MINER_TITLES.put(230, "&7[&6&l✦✦✦ GOTT DER ERDE&7] &r");

        WOODCUTTER_TITLES.put(10, "&7[&a&lAstsammler&7] &r");
        WOODCUTTER_TITLES.put(20, "&7[&f&lBaumfäller&7] &r");
        WOODCUTTER_TITLES.put(30, "&7[&e&lWaldläufer&7] &r");
        WOODCUTTER_TITLES.put(40, "&7[&2&lHolzknecht&7] &r");
        WOODCUTTER_TITLES.put(50, "&7[&b&lForstmann&7] &r");
        WOODCUTTER_TITLES.put(60, "&7[&6&lWaldhüter&7] &r");
        WOODCUTTER_TITLES.put(70, "&7[&d&lEichenspalter&7] &r");
        WOODCUTTER_TITLES.put(80, "&7[&c&lHolzmeister&7] &r");
        WOODCUTTER_TITLES.put(90, "&7[&4&lDschungelkönig&7] &r");
        WOODCUTTER_TITLES.put(100, "&7[&2&l★ Waldfürst&7] &r");
        WOODCUTTER_TITLES.put(110, "&7[&a&lBaumpatriarch&7] &r");
        WOODCUTTER_TITLES.put(120, "&7[&3&lNetherholzfäller&7] &r");
        WOODCUTTER_TITLES.put(130, "&7[&5&lKrimsonschnitter&7] &r");
        WOODCUTTER_TITLES.put(140, "&7[&9&lWurzelmeister&7] &r");
        WOODCUTTER_TITLES.put(150, "&7[&6&l✦ Waldkaiser&7] &r");
        WOODCUTTER_TITLES.put(160, "&7[&1&lSchattenholzer&7] &r");
        WOODCUTTER_TITLES.put(170, "&7[&d&lMangrovenkönig&7] &r");
        WOODCUTTER_TITLES.put(180, "&7[&e&lUrwaldfürst&7] &r");
        WOODCUTTER_TITLES.put(190, "&7[&4&lNachtholzer&7] &r");
        WOODCUTTER_TITLES.put(200, "&7[&a&l✦✦ Waldlegende&7] &r");
        WOODCUTTER_TITLES.put(210, "&7[&2&lUrbaummeister&7] &r");
        WOODCUTTER_TITLES.put(220, "&7[&6&l★★ Forstgott&7] &r");
        WOODCUTTER_TITLES.put(230, "&7[&a&l✦✦✦ GOTT DES WALDES&7] &r");

        HUNTER_TITLES.put(10, "&7[&f&lAnfängerjäger&7] &r");
        HUNTER_TITLES.put(20, "&7[&e&lMonsterjäger&7] &r");
        HUNTER_TITLES.put(30, "&7[&a&lWildjäger&7] &r");
        HUNTER_TITLES.put(40, "&7[&6&lKopfjäger&7] &r");
        HUNTER_TITLES.put(50, "&7[&b&lSchattenpfeil&7] &r");
        HUNTER_TITLES.put(60, "&7[&d&lKlingenmeister&7] &r");
        HUNTER_TITLES.put(70, "&7[&2&lNetherjäger&7] &r");
        HUNTER_TITLES.put(80, "&7[&c&lZombieschlächter&7] &r");
        HUNTER_TITLES.put(90, "&7[&5&lEndermantöter&7] &r");
        HUNTER_TITLES.put(100, "&7[&6&l★ Monsterfänger&7] &r");
        HUNTER_TITLES.put(110, "&7[&e&lDrachentöter&7] &r");
        HUNTER_TITLES.put(120, "&7[&b&lKampfmeister&7] &r");
        HUNTER_TITLES.put(130, "&7[&4&lBlutritter&7] &r");
        HUNTER_TITLES.put(140, "&7[&9&lSchattenkönig&7] &r");
        HUNTER_TITLES.put(150, "&7[&e&l✦ Kriegerfürst&7] &r");
        HUNTER_TITLES.put(160, "&7[&1&lSeelenjäger&7] &r");
        HUNTER_TITLES.put(170, "&7[&d&lHöllenschlächter&7] &r");
        HUNTER_TITLES.put(180, "&7[&6&lChaosbringer&7] &r");
        HUNTER_TITLES.put(190, "&7[&5&lSchattenherr&7] &r");
        HUNTER_TITLES.put(200, "&7[&c&l✦✦ Kampflegende&7] &r");
        HUNTER_TITLES.put(210, "&7[&4&lUnsterblicher Krieger&7] &r");
        HUNTER_TITLES.put(220, "&7[&e&l★★ Kriegsgott&7] &r");
        HUNTER_TITLES.put(230, "&7[&c&l✦✦✦ GOTT DES KRIEGES&7] &r");

        FISHER_TITLES.put(10, "&7[&f&lWurmwerfer&7] &r");
        FISHER_TITLES.put(20, "&7[&b&lAngelkünstler&7] &r");
        FISHER_TITLES.put(30, "&7[&a&lNetzschwinger&7] &r");
        FISHER_TITLES.put(40, "&7[&6&lLachsjäger&7] &r");
        FISHER_TITLES.put(50, "&7[&3&lMeereskundler&7] &r");
        FISHER_TITLES.put(60, "&7[&e&lTieftaucher&7] &r");
        FISHER_TITLES.put(70, "&7[&d&lKorallensucher&7] &r");
        FISHER_TITLES.put(80, "&7[&9&lMeeresjäger&7] &r");
        FISHER_TITLES.put(90, "&7[&2&lWellenreiter&7] &r");
        FISHER_TITLES.put(100, "&7[&3&l★ Meeresherrscher&7] &r");
        FISHER_TITLES.put(110, "&7[&b&lKrakenbezwinger&7] &r");
        FISHER_TITLES.put(120, "&7[&e&lOzeanmeister&7] &r");
        FISHER_TITLES.put(130, "&7[&1&lTiefseekönig&7] &r");
        FISHER_TITLES.put(140, "&7[&5&lTridentenwächter&7] &r");
        FISHER_TITLES.put(150, "&7[&6&l✦ Meeresfürst&7] &r");
        FISHER_TITLES.put(160, "&7[&3&lSchattentaucher&7] &r");
        FISHER_TITLES.put(170, "&7[&d&lAbyssherrscher&7] &r");
        FISHER_TITLES.put(180, "&7[&6&lPoseidons Erbe&7] &r");
        FISHER_TITLES.put(190, "&7[&4&lMeeresschatten&7] &r");
        FISHER_TITLES.put(200, "&7[&b&l✦✦ Ozeanlegende&7] &r");
        FISHER_TITLES.put(210, "&7[&9&lEwiger Fischer&7] &r");
        FISHER_TITLES.put(220, "&7[&3&l★★ Meeresgott&7] &r");
        FISHER_TITLES.put(230, "&7[&b&l✦✦✦ GOTT DES MEERES&7] &r");

        DIGGER_TITLES.put(10, "&7[&f&lSchaufelschwinger&7] &r");
        DIGGER_TITLES.put(20, "&7[&a&lErdwühler&7] &r");
        DIGGER_TITLES.put(30, "&7[&6&lSandgräber&7] &r");
        DIGGER_TITLES.put(40, "&7[&b&lLehmsammler&7] &r");
        DIGGER_TITLES.put(50, "&7[&d&lBodenkundler&7] &r");
        DIGGER_TITLES.put(60, "&7[&e&lErdmeister&7] &r");
        DIGGER_TITLES.put(70, "&7[&2&lHöhlengräber&7] &r");
        DIGGER_TITLES.put(80, "&7[&c&lSandstürmer&7] &r");
        DIGGER_TITLES.put(90, "&7[&3&lSeelensandgräber&7] &r");
        DIGGER_TITLES.put(100, "&7[&e&l★ Erdkönig&7] &r");
        DIGGER_TITLES.put(110, "&7[&a&lTiefengräber&7] &r");
        DIGGER_TITLES.put(120, "&7[&b&lLehmfürst&7] &r");
        DIGGER_TITLES.put(130, "&7[&5&lMystischer Gräber&7] &r");
        DIGGER_TITLES.put(140, "&7[&6&lSchlammpfadfinder&7] &r");
        DIGGER_TITLES.put(150, "&7[&e&l✦ Bodenfürst&7] &r");
        DIGGER_TITLES.put(160, "&7[&1&lErdschatten&7] &r");
        DIGGER_TITLES.put(170, "&7[&4&lTiefenwühler&7] &r");
        DIGGER_TITLES.put(180, "&7[&2&lErdfürst&7] &r");
        DIGGER_TITLES.put(190, "&7[&d&lUnterweltgräber&7] &r");
        DIGGER_TITLES.put(200, "&7[&6&l✦✦ Bodenlegende&7] &r");
        DIGGER_TITLES.put(210, "&7[&9&lEwiger Gräber&7] &r");
        DIGGER_TITLES.put(220, "&7[&e&l★★ Erdgott&7] &r");
        DIGGER_TITLES.put(230, "&7[&6&l✦✦✦ GOTT DER ERDE&7] &r");
    }
}
