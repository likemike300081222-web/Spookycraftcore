package de.craftsucht.core.rank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.scoreboard.ScoreboardModule;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class RankListener implements Listener {

    private final SpookyCraftCore plugin;
    private final RankManager manager;

    public RankListener(SpookyCraftCore plugin, RankManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent event) {
        manager.apply(event.getPlayer());
        refreshVisuals();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        manager.remove(event.getPlayer());
    }

    /**
     * Setzt den Rang-Prefix vor den Spielernamen im Chat. Läuft NACH dem
     * Mute-Check (LOWEST) und VOR dem Clan-Chat-Handler (NORMAL), und wird
     * bei einem bereits abgebrochenen Event (z.B. gemutet) übersprungen.
     * Spieler mit "craftsucht.chat.color" dürfen &-Farbcodes in ihrer
     * Nachricht benutzen, die werden dann hier übersetzt; alle anderen
     * schreiben ganz normal (& bleibt als reiner Text sichtbar).
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        String prefix = manager.getColoredPrefix(event.getPlayer().getUniqueId());
        String nameColor = getJobNameColor(event.getPlayer());
        String format = (prefix.isEmpty() ? "" : prefix + "§r: ") + nameColor + "%1$s §f%2$s";
        event.setFormat(format);

        if (event.getPlayer().hasPermission("craftsucht.chat.color")) {
            event.setMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&', event.getMessage()));
        }
    }

    /**
     * Nur die Farbe (kein Text) aus dem höchsten erreichten Job-Titel (siehe
     * jobs-Modul/RewardManager), leerer String falls kein Jobs-Modul aktiv
     * oder noch kein Titel-Level erreicht - dann bleibt die Standardfarbe.
     */
    private String getJobNameColor(org.bukkit.entity.Player p) {
        Module m = plugin.getModuleManager().get("jobs");
        if (!(m instanceof de.craftsucht.core.jobs.JobsModule jobsModule)) return "";
        de.craftsucht.core.jobs.PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return "";
        org.bukkit.ChatColor color = jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
        return color != null ? color.toString() : "";
    }

    private void refreshVisuals() {
        Module m = plugin.getModuleManager().get("scoreboard");
        if (m instanceof ScoreboardModule sm) {
            sm.refreshNow();
        }
    }
}
