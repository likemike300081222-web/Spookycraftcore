package de.craftsucht.core.tablist;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/** Simple header/footer tab-list branding; per-rank formatting can hook into LuckPerms later. */
public class TabListModule implements Module {

    private final SpookyCraftCore plugin;
    private BukkitTask task;

    public TabListModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "tablist";
    }

    @Override
    public void enable() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::update, 20L, 100L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
    }

    private void update() {
        String header = plugin.getMessageUtil().color("&6&lSpookyCraft\n&7Willkommen auf dem Server!");
        String footer = plugin.getMessageUtil().color("&7Online: &b" + Bukkit.getOnlinePlayers().size());
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.setPlayerListHeaderFooter(header, footer);
        }
    }
}
