package de.craftsucht.core.jobs;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Verwaltet die vom Spieler selbst per /prefix ausgewählte Namensfarbe.
 * Unterstützt sowohl normale Farben (aus den Job-Titel-Meilensteinen, immer
 * legacy org.bukkit.ChatColor) als auch beliebige Hex-Farben. WICHTIG:
 * org.bukkit.ChatColor selbst hat KEINE Hex-Unterstützung (kein .of(String),
 * kein .getColor()) - das ist nur die alte 16-Farben-Klasse. Hex-Farben
 * werden hier deshalb als reine Text-Farbcode-Strings gehandhabt
 * ("§x§R§R§G§G§B§B"), nicht als ChatColor-Objekt.
 */
public class PrefixColorManager {

    private static final Pattern HEX_PATTERN = Pattern.compile("^[0-9A-Fa-f]{6}$");

    /** Offizielle RGB-Werte der 16 legacy Minecraft-Farben (fest, ändert sich nie). */
    private static final Map<ChatColor, String> LEGACY_HEX = new EnumMap<>(ChatColor.class);

    static {
        LEGACY_HEX.put(ChatColor.BLACK, "000000");
        LEGACY_HEX.put(ChatColor.DARK_BLUE, "0000AA");
        LEGACY_HEX.put(ChatColor.DARK_GREEN, "00AA00");
        LEGACY_HEX.put(ChatColor.DARK_AQUA, "00AAAA");
        LEGACY_HEX.put(ChatColor.DARK_RED, "AA0000");
        LEGACY_HEX.put(ChatColor.DARK_PURPLE, "AA00AA");
        LEGACY_HEX.put(ChatColor.GOLD, "FFAA00");
        LEGACY_HEX.put(ChatColor.GRAY, "AAAAAA");
        LEGACY_HEX.put(ChatColor.DARK_GRAY, "555555");
        LEGACY_HEX.put(ChatColor.BLUE, "5555FF");
        LEGACY_HEX.put(ChatColor.GREEN, "55FF55");
        LEGACY_HEX.put(ChatColor.AQUA, "55FFFF");
        LEGACY_HEX.put(ChatColor.RED, "FF5555");
        LEGACY_HEX.put(ChatColor.LIGHT_PURPLE, "FF55FF");
        LEGACY_HEX.put(ChatColor.YELLOW, "FFFF55");
        LEGACY_HEX.put(ChatColor.WHITE, "FFFFFF");
    }

    private final SpookyCraftCore plugin;
    private final Map<UUID, String> cache = new HashMap<>();

    public PrefixColorManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public static boolean isValidHex(String input) {
        return HEX_PATTERN.matcher(input).matches();
    }

    /** Wandelt eine legacy ChatColor in ihren offiziellen Hex-Wert um (für die Speicherung). */
    public static String toHex(ChatColor color) {
        return LEGACY_HEX.getOrDefault(color, "FFFFFF");
    }

    /**
     * Baut aus einem 6-stelligen Hex-String die fertige Minecraft-Farbcode-
     * Sequenz "§x§R§R§G§G§B§B", die einfach vor Text gesetzt werden kann.
     */
    public static String toColorCode(String hex) {
        StringBuilder sb = new StringBuilder("§x");
        for (char c : hex.toUpperCase().toCharArray()) {
            sb.append('§').append(c);
        }
        return sb.toString();
    }

    /** Gibt die fertige Farbcode-Sequenz für die gespeicherte Farbe zurück, oder null falls keine gewählt. */
    public String getSelectedColorCode(UUID uuid) {
        String hex = getSelectedHex(uuid);
        return hex != null ? toColorCode(hex) : null;
    }

    public String getSelectedHex(UUID uuid) {
        if (cache.containsKey(uuid)) {
            return cache.get(uuid);
        }
        String hex = load(uuid);
        cache.put(uuid, hex);
        return hex;
    }

    private String load(UUID uuid) {
        String sql = "SELECT color FROM player_prefix_color WHERE uuid = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString("color");
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Prefix-Farbe laden fehlgeschlagen: " + e.getMessage());
        }
        return null;
    }

    public void setColor(UUID uuid, String hex) {
        cache.put(uuid, hex);
        String sql = "INSERT INTO player_prefix_color (uuid, color) VALUES (?,?) " +
                "ON CONFLICT(uuid) DO UPDATE SET color = excluded.color";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, hex);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Prefix-Farbe speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    public void clearColor(UUID uuid) {
        cache.remove(uuid);
        String sql = "DELETE FROM player_prefix_color WHERE uuid = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Prefix-Farbe löschen fehlgeschlagen: " + e.getMessage());
        }
    }
}
