package de.craftsucht.core.module;

public interface Module {
    String getId();
    void enable();
    void disable();
    default void reload() {
        disable();
        enable();
    }
}
