package de.craftsucht.core.punish;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

public class PunishModule implements Module {

    private final SpookyCraftCore plugin;
    private PunishManager manager;
    private PunishListener listener;

    public PunishModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "punish";
    }

    @Override
    public void enable() {
        this.manager = new PunishManager(plugin);
        PunishCommand command = new PunishCommand(plugin, manager);
        for (String cmd : new String[]{"punish", "ban", "unban", "tempban", "warn", "kick", "mute", "unmute", "history"}) {
            plugin.getCommand(cmd).setExecutor(command);
            plugin.getCommand(cmd).setTabCompleter(command);
        }

        this.listener = new PunishListener(manager);
        Bukkit.getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) {
            HandlerList.unregisterAll(listener);
        }
    }
}
