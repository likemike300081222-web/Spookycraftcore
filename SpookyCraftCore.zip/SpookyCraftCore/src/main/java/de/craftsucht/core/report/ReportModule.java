package de.craftsucht.core.report;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.sql.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReportModule implements Module, CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;

    public ReportModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "report";
    }

    @Override
    public void enable() {
        plugin.getCommand("report").setExecutor(this);
        plugin.getCommand("report").setTabCompleter(this);
    }

    @Override
    public void disable() {
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /report <spieler> <grund>");
            return true;
        }
        String reason = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        String sql = "INSERT INTO reports (reporter, target, reason, created_at, handled) VALUES (?,?,?,?,0)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setString(2, args[0]);
            ps.setString(3, reason);
            ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
            plugin.getMessageUtil().send(p, "&aReport eingereicht. Ein Teammitglied wird sich darum kümmern.");
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.isOp() || staff.hasPermission("craftsucht.core.admin")) {
                    plugin.getMessageUtil().send(staff, "&e[Report] &b" + p.getName() + " &7meldet &b" + args[0] + "&7: " + reason);
                }
            }
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Melden.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return TabCompleteUtil.onlinePlayers(args[0]);
        }
        return Collections.emptyList();
    }
}
