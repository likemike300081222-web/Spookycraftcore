package de.craftsucht.core.alert;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;

public class AlertModule implements Module {

    private final SpookyCraftCore plugin;

    public AlertModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "alert";
    }

    @Override
    public void enable() {
        AlertCommand command = new AlertCommand(plugin);
        plugin.getCommand("alert").setExecutor(command);
        plugin.getCommand("alert").setTabCompleter(command);
    }

    @Override
    public void disable() {
        // stateless, nichts aufzuräumen
    }
}
