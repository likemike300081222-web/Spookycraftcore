package de.craftsucht.core.jobs;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Actionbar im Stil der gewünschten Jobs-Bar. Zeigt alle Jobs abwechselnd. */
public class JobsBar {
    private final JobsModule jobs;
    private BukkitTask task;
    private final Map<UUID, Integer> rotation = new HashMap<>();
    private int tick = 0;

    public JobsBar(JobsModule jobs) { this.jobs = jobs; }

    public void start() {
        stop();
        task = Bukkit.getScheduler().runTaskTimer(jobs.plugin, () -> {
            tick++;
            for (Player player : Bukkit.getOnlinePlayers()) show(player);
        }, 1L, 20L);
    }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
        rotation.clear();
    }

    private void show(Player player) {
        List<String> jobIds = jobs.getJobManager().getAvailableJobs();
        if (jobIds.isEmpty()) return;
        UUID uuid = player.getUniqueId();
        int index = rotation.computeIfAbsent(uuid, ignored -> 0);
        if (tick % 4 == 0) {
            index = (index + 1) % jobIds.size();
            rotation.put(uuid, index);
        }

        String jobId = jobIds.get(index);
        PlayerData data = jobs.getPlayerDataManager().get(uuid);
        JobData jd = data.getOrCreateJob(jobId);
        int xp = jd.getXp();
        int needed = jd.getXpForNextLevel();
        double percent = needed <= 0 ? 1.0 : Math.min(1.0, (double) xp / needed);
        int bars = 20;
        int filled = (int) Math.round(percent * bars);
        StringBuilder progress = new StringBuilder();
        for (int i = 0; i < bars; i++) progress.append(i < filled ? "§a▌" : "§7▌");

        String display = jobs.getJobManager().getJobDisplayName(jobId);
        String bar = ChatColor.WHITE + "+" + jobs.getJobManager().getXpPerAction() + " XP"
                + ChatColor.DARK_GRAY + " • " + ChatColor.GREEN + "Jobgeld pro Aktion"
                + ChatColor.DARK_GRAY + " • " + display + ChatColor.WHITE + " Level " + jd.getLevel()
                + ChatColor.DARK_GRAY + " • " + progress
                + ChatColor.GRAY + " " + xp + "/" + needed;
        player.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(bar));
    }
}
