package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

public class ShopManager {

    private final SpookyCraftCore plugin;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();

    public ShopManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void load() {
        categories.clear();
        File file = new File(plugin.getDataFolder(), "shop.yml");
        if (!file.exists()) {
            plugin.saveResource("shop.yml", false);
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection categoriesSection = config.getConfigurationSection("categories");
        if (categoriesSection == null) {
            plugin.getLogger().warning("shop.yml enthält keine 'categories'-Sektion.");
            return;
        }
        for (String key : categoriesSection.getKeys(false)) {
            ConfigurationSection catSection = categoriesSection.getConfigurationSection(key);
            if (catSection == null) continue;
            String displayName = catSection.getString("display-name", key);
            Material icon = Material.matchMaterial(catSection.getString("icon", "CHEST"));
            if (icon == null) icon = Material.CHEST;
            int slot = catSection.getInt("slot", 0);
            ShopCategory category = new ShopCategory(key, displayName, icon, slot);
            for (Map<?, ?> raw : catSection.getMapList("items")) {
                Object matObj = raw.get("material");
                if (matObj == null) continue;
                Material material = Material.matchMaterial(matObj.toString());
                if (material == null) {
                    plugin.getLogger().warning("Unbekanntes Material in shop.yml: " + matObj);
                    continue;
                }
                double buyPrice = toDouble(raw.get("buy-price"));
                double sellPrice = toDouble(raw.get("sell-price"));
                category.addItem(new ShopItem(material, buyPrice, sellPrice));
            }
            categories.put(key, category);
        }
        plugin.getLogger().info("Markt geladen: " + categories.size() + " Kategorien.");
    }

    private double toDouble(Object o) {
        if (o instanceof Number number) {
            return number.doubleValue();
        }
        return 0.0;
    }

    public Map<String, ShopCategory> getCategories() {
        return categories;
    }
}
