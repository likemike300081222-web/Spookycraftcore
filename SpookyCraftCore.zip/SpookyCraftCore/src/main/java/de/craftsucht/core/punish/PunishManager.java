package de.craftsucht.core.punish;

import de.craftsucht.core.SpookyCraftCore;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PunishManager {

    private final SpookyCraftCore plugin;

    public SpookyCraftCore getPlugin() { return plugin; }

    public PunishManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void addPunishment(UUID uuid, String type, String reason, String staff, long expiresAt) {
        String sql = "INSERT INTO punishments (uuid, type, reason, staff, created_at, expires_at, active) VALUES (?,?,?,?,?,?,1)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, type);
            ps.setString(3, reason);
            ps.setString(4, staff);
            ps.setLong(5, System.currentTimeMillis());
            ps.setLong(6, expiresAt);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Punish addPunishment fehlgeschlagen: " + e.getMessage());
        }
    }

    /** Loggt einen inaktiven Eintrag (z.B. UNBAN/UNMUTE), ohne den Spieler zu bestrafen. */
    private void addLogOnly(UUID uuid, String type, String staff) {
        String sql = "INSERT INTO punishments (uuid, type, reason, staff, created_at, expires_at, active) VALUES (?,?,?,?,?,0,0)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, type);
            ps.setString(3, "-");
            ps.setString(4, staff);
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Punish addLogOnly fehlgeschlagen: " + e.getMessage());
        }
    }

    /** Returns the active ban reason for a player, or null if not banned. */
    public BanRecord getActiveBan(UUID uuid) {
        String sql = "SELECT reason, staff, created_at, expires_at FROM punishments WHERE uuid = ? AND type IN ('BAN','TEMPBAN') AND active = 1 ORDER BY created_at DESC LIMIT 1";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    long expiresAt = rs.getLong("expires_at");
                    if (expiresAt != 0 && expiresAt < System.currentTimeMillis()) {
                        clearBans(uuid, "AUTO");
                        return null;
                    }
                    return new BanRecord(rs.getString("reason"), rs.getString("staff"), rs.getLong("created_at"), expiresAt);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Punish getActiveBan fehlgeschlagen: " + e.getMessage());
        }
        return null;
    }

    /** Baut den Ban-Screen (mit &-Farbcodes übersetzt) - gilt für Join UND Kick bei laufender Session. */
    public String buildBanScreen(BanRecord ban) {
        String duration = ban.expiresAt() == 0 ? "Permanent" : formatDuration(ban.expiresAt() - System.currentTimeMillis());
        String banId = Long.toHexString(ban.createdAt()).toUpperCase();
        String discord = plugin.getConfig().getString("punishment.ban-screen.discord", "").trim();
        String discordLine = discord.isEmpty() ? "" : "\n\n&7Discord: &f" + discord;
        String message = "&6&lSpookyCraft\n\n" +
                "&c&lDu wurdest vom Server gebannt!\n\n" +
                "&7Grund: &f" + ban.reason() + "\n" +
                "&7Dauer: &f" + duration + "\n" +
                "&7Gebannt von: &f" + ban.staff() + "\n" +
                "&7Ban-ID: &f" + banId + discordLine;
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', message);
    }

    public String formatDuration(long millis) {
        if (millis <= 0) return "abgelaufen";
        long totalMinutes = (millis + 59_999L) / 60_000L; // aufrunden, sonst steht bei 1d "23 Std. 59 Min."
        long days = totalMinutes / 1440;
        long hours = (totalMinutes % 1440) / 60;
        long minutes = totalMinutes % 60;
        if (days > 0) return days + " Tag(e) " + hours + " Std.";
        if (hours > 0) return hours + " Std. " + minutes + " Min.";
        return Math.max(1, minutes) + " Min.";
    }

    /** Wie oft wurde der Spieler schon mit genau diesem Grund gebannt bzw. gemutet (auch erledigte/aufgehobene)? */
    public int countReasonHistory(UUID uuid, String reasonName, boolean ban) {
        String types = ban ? "('BAN','TEMPBAN')" : "('MUTE')";
        String sql = "SELECT COUNT(*) FROM punishments WHERE uuid = ? AND type IN " + types + " AND (reason = ? OR reason LIKE ?)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, reasonName);
            ps.setString(3, reasonName + " - %");
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Punish countReasonHistory fehlgeschlagen: " + e.getMessage());
        }
        return 0;
    }

    public String getActiveBanReason(UUID uuid) {
        BanRecord ban = getActiveBan(uuid);
        return ban == null ? null : ban.reason();
    }

    /** Returns the active mute reason for a player, or null if not muted. */
    public String getActiveMuteReason(UUID uuid) {
        String sql = "SELECT reason, expires_at FROM punishments WHERE uuid = ? AND type = 'MUTE' AND active = 1 ORDER BY created_at DESC LIMIT 1";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    long expiresAt = rs.getLong("expires_at");
                    if (expiresAt != 0 && expiresAt < System.currentTimeMillis()) {
                        clearMutes(uuid, "AUTO");
                        return null;
                    }
                    return rs.getString("reason");
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Punish getActiveMuteReason fehlgeschlagen: " + e.getMessage());
        }
        return null;
    }

    public void clearBans(UUID uuid, String staff) {
        String sql = "UPDATE punishments SET active = 0 WHERE uuid = ? AND type IN ('BAN','TEMPBAN')";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
            addLogOnly(uuid, "UNBAN", staff);
        } catch (SQLException e) {
            plugin.getLogger().warning("Punish clearBans fehlgeschlagen: " + e.getMessage());
        }
    }

    public void clearMutes(UUID uuid, String staff) {
        String sql = "UPDATE punishments SET active = 0 WHERE uuid = ? AND type = 'MUTE'";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
            addLogOnly(uuid, "UNMUTE", staff);
        } catch (SQLException e) {
            plugin.getLogger().warning("Punish clearMutes fehlgeschlagen: " + e.getMessage());
        }
    }

    /** Letzte Strafen eines Spielers, neueste zuerst. */
    public List<PunishmentRecord> getHistory(UUID uuid, int limit) {
        List<PunishmentRecord> result = new ArrayList<>();
        String sql = "SELECT type, reason, staff, created_at, expires_at, active FROM punishments WHERE uuid = ? ORDER BY created_at DESC LIMIT ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(new PunishmentRecord(
                            rs.getString("type"),
                            rs.getString("reason"),
                            rs.getString("staff"),
                            rs.getLong("created_at"),
                            rs.getLong("expires_at"),
                            rs.getInt("active") == 1
                    ));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Punish getHistory fehlgeschlagen: " + e.getMessage());
        }
        return result;
    }

    public record PunishmentRecord(String type, String reason, String staff, long createdAt, long expiresAt, boolean active) {
    }

    public record BanRecord(String reason, String staff, long createdAt, long expiresAt) {
    }
}
