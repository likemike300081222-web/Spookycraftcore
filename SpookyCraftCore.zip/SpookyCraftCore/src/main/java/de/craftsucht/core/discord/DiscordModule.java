package de.craftsucht.core.discord;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Sends join/leave/chat events to a Discord webhook. Set discord.webhook-url in config.yml. */
public class DiscordModule implements Module, Listener {

    private final SpookyCraftCore plugin;
    private String webhookUrl;

    public DiscordModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "discord";
    }

    @Override
    public void enable() {
        webhookUrl = plugin.getConfig().getString("discord.webhook-url", "");
        if (webhookUrl == null || webhookUrl.isBlank()) {
            plugin.getLogger().warning("Discord-Modul aktiv, aber keine webhook-url in config.yml gesetzt.");
        }
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        send("**" + event.getPlayer().getName() + "** ist dem Server beigetreten.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        send("**" + event.getPlayer().getName() + "** hat den Server verlassen.");
    }

    /** Fire-and-forget async POST to the Discord webhook. */
    public void send(String content) {
        if (webhookUrl == null || webhookUrl.isBlank()) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                URL url = new URL(webhookUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                String json = "{\"content\":\"" + content.replace("\"", "\\\"") + "\"}";
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }
                conn.getResponseCode();
                conn.disconnect();
            } catch (Exception e) {
                plugin.getLogger().warning("Discord-Webhook fehlgeschlagen: " + e.getMessage());
            }
        });
    }
}
