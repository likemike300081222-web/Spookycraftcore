package de.craftsucht.core.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** Shared helpers for building TabCompleter suggestion lists. */
public final class TabCompleteUtil {

    private TabCompleteUtil() {
    }

    /** All online player names starting with the given (possibly empty) prefix. */
    public static List<String> onlinePlayers(String prefix) {
        List<String> result = new ArrayList<>();
        String lower = prefix.toLowerCase();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getName().toLowerCase().startsWith(lower)) {
                result.add(p.getName());
            }
        }
        return result;
    }

    /** Filters a fixed list of options (subcommands, enums, etc.) by prefix. */
    public static List<String> filter(String prefix, String... options) {
        List<String> result = new ArrayList<>();
        String lower = prefix.toLowerCase();
        for (String option : options) {
            if (option.toLowerCase().startsWith(lower)) {
                result.add(option);
            }
        }
        return result;
    }
}
