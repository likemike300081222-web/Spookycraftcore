package de.craftsucht.core.jobs;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class PrefixGuiHolder implements InventoryHolder {

    public enum Type {
        MILESTONES,
        JOB_SELECT
    }

    private final Type type;
    private final String jobId;
    private Inventory inventory;

    public PrefixGuiHolder(Type type, String jobId) {
        this.type = type;
        this.jobId = jobId;
    }

    public Type getType() {
        return type;
    }

    public String getJobId() {
        return jobId;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
