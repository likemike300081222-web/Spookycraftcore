package de.craftsucht.core.anticheat;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Very lightweight fly/speed sanity checks — flags suspicious movement to staff.
 * This is NOT a replacement for a dedicated anticheat plugin; it's a cheap first line of defense.
 * Disabled by default in config.yml (modules.anticheat: false) to avoid false-positive spam.
 */
public class AntiCheatModule implements Module, Listener {

    private final SpookyCraftCore plugin;
    private final Map<UUID, Long> lastWarn = new HashMap<>();

    public AntiCheatModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "anticheat";
    }

    @Override
    public void enable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        lastWarn.clear();
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player p = event.getPlayer();
        if (p.getAllowFlight() || p.isFlying() || p.getGameMode() == org.bukkit.GameMode.CREATIVE
                || p.getGameMode() == org.bukkit.GameMode.SPECTATOR) return;
        if (event.getFrom().distance(event.getTo()) > 10) {
            long now = System.currentTimeMillis();
            if (now - lastWarn.getOrDefault(p.getUniqueId(), 0L) < 10_000) return;
            lastWarn.put(p.getUniqueId(), now);
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.isOp() || staff.hasPermission("craftsucht.core.admin")) {
                    plugin.getMessageUtil().send(staff, "&e[AntiCheat] &b" + p.getName() + " &7hat sich verdächtig schnell bewegt.");
                }
            }
        }
    }
}
