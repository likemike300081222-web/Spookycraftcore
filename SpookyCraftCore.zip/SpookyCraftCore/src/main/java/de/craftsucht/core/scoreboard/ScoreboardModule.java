package de.craftsucht.core.scoreboard;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.jobs.JobsModule;
import de.craftsucht.core.jobs.PlayerData;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.rank.RankModule;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Live sidebar scoreboard im Opsucht-artigen "»"-Bullet-Stil: Rang, Geld,
 * Server (aktuelle Multiverse-Welt). Synchronisiert außerdem pro Tick den
 * Rang-Prefix in Tabliste und Nametag über dem Kopf (per Scoreboard-Team),
 * damit ein neuer/angepasster Rang überall sofort sichtbar ist.
 */
public class ScoreboardModule implements Module {

    private final SpookyCraftCore plugin;
    private BukkitTask task;

    public ScoreboardModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "scoreboard";
    }

    @Override
    public void enable() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::updateAll, 20L, 40L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            p.setPlayerListName(null);
        }
    }

    /** Erzwingt ein sofortiges Update (z.B. direkt nach /rank create|setprefix|user set). */
    public void refreshNow() {
        updateAll();
    }

    private void updateAll() {
        EconomyModule economyModule = (EconomyModule) plugin.getModuleManager().get("economy");
        RankModule rankModule = (RankModule) plugin.getModuleManager().get("rank");
        JobsModule jobsModule = (JobsModule) plugin.getModuleManager().get("jobs");

        // Einmal pro Durchlauf den Rang-Prefix + Job-Titel-Farbe je Online-Spieler
        // berechnen, damit unten für Sidebar, Team-Nametag und Tabliste wiederverwendet wird.
        Map<Player, String> prefixes = new HashMap<>();
        Map<Player, String> nameColorCodes = new HashMap<>();
        Map<Player, ChatColor> teamColors = new HashMap<>();
        for (Player online : Bukkit.getOnlinePlayers()) {
            prefixes.put(online, getRangPrefix(online, rankModule));
            nameColorCodes.put(online, getJobNameColorCode(online, jobsModule));
            teamColors.put(online, getLegacyTeamColor(online, jobsModule));
        }

        for (Player p : Bukkit.getOnlinePlayers()) {
            Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
            Objective obj = board.registerNewObjective("bc", "dummy", "§6§lSpookyCraft");
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
            // Blendet die Score-Zahl rechts neben jeder Zeile aus (Paper-API).
            obj.numberFormat(NumberFormat.blank());

            int line = 10;
            obj.getScore("§8§m----------------").setScore(line--);

            String rang = prefixes.get(p);
            obj.getScore("§8» §7Rang: " + (rang.isEmpty() ? "§7Spieler" : rang)).setScore(line--);

            if (economyModule != null) {
                double bal = economyModule.getManager().getBalance(p.getUniqueId());
                String formatted = String.format(Locale.GERMANY, "%,.0f", bal);
                obj.getScore("§8» §7Geld: §a$" + formatted).setScore(line--);
            }

            obj.getScore("§8» §7Server: §b" + prettyWorldName(p.getWorld().getName())).setScore(line--);

            obj.getScore(" ").setScore(line--);
            obj.getScore("§8§m-----------------").setScore(line--);

            // Teams für Nametag-Farbe: jeder Online-Spieler bekommt sein Team im
            // Scoreboard DIESES Betrachters zugewiesen - nur so färbt sich der
            // Name über dem Kopf und in der Tabliste für alle mit. Gruppiert nach
            // Prefix+Teamfarbe zusammen (zwei Spieler mit gleichem Rang aber
            // unterschiedlicher Job-Titel-Farbe brauchen unterschiedliche Teams).
            Map<String, Team> teamsByKey = new HashMap<>();
            int teamIndex = 0;
            for (Player other : Bukkit.getOnlinePlayers()) {
                String otherPrefix = prefixes.get(other);
                ChatColor otherTeamColor = teamColors.get(other);
                String key = otherPrefix + "|" + otherTeamColor;
                Team team = teamsByKey.get(key);
                if (team == null) {
                    team = board.registerNewTeam("r" + (teamIndex++));
                    team.setPrefix(otherPrefix.isEmpty() ? "" : otherPrefix + "§r: ");
                    // Team#setColor() kennt nur die 16 klassischen Farben, keine Hex-Werte -
                    // deswegen kommt hier nur eine bereits geprüfte legacy ChatColor rein
                    // (siehe getLegacyTeamColor). Chat/Tabliste zeigen Hex trotzdem korrekt an.
                    if (otherTeamColor != null) team.setColor(otherTeamColor);
                    team.setAllowFriendlyFire(true);
                    teamsByKey.put(key, team);
                }
                if (!team.hasEntry(other.getName())) {
                    team.addEntry(other.getName());
                }
            }

            p.setScoreboard(board);
            String myColorCode = nameColorCodes.get(p);
            p.setPlayerListName((rang.isEmpty() ? "" : rang + "§r: ") + (myColorCode != null ? myColorCode : "") + p.getName());
        }
    }

    /**
     * Nutzt IMMER das eigene interne Rang-System (/rank create|user set) als
     * Quelle - auch wenn LuckPerms zusätzlich auf dem Server installiert ist,
     * da /rank nicht in LuckPerms schreibt und LuckPerms sonst mit seiner
     * eigenen (leeren) Standardgruppe den selbst erstellten Rang überdecken würde.
     */
    private String getRangPrefix(Player p, RankModule rankModule) {
        if (rankModule != null) {
            String prefix = rankModule.getManager().getColoredPrefix(p.getUniqueId());
            if (!prefix.isEmpty()) {
                return prefix;
            }
        }
        return p.isOp() ? "§4§lOwner" : "";
    }

    /** Erster Buchstabe groß, Unterstriche zu Leerzeichen - aus "world_nether" wird "World Nether". */
    private String prettyWorldName(String raw) {
        String[] parts = raw.replace('_', ' ').split(" ");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    /**
     * Fertige Farbcode-Sequenz für Chat/Tabliste - Farbe des höchsten
     * erreichten Job-Titels. Leerer String = keine (kein Jobs-Modul, kein
     * Job, noch kein Titel-Level erreicht).
     */
    private String getJobNameColorCode(Player p, JobsModule jobsModule) {
        if (jobsModule == null) return "";
        PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return "";
        ChatColor color = jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
        return color != null ? color.toString() : "";
    }

    /** Nametag-Farbe (Scoreboard-Team) - dieselbe Job-Tier-Farbe, immer eine legacy ChatColor. */
    private ChatColor getLegacyTeamColor(Player p, JobsModule jobsModule) {
        if (jobsModule == null) return null;
        PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return null;
        return jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
    }
}
