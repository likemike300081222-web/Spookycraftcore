package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Kauf-/Verkaufslogik fürs Markt-GUI. Nutzt bewusst NICHT Vault (wie das
 * ursprüngliche eigenständige MarktPlugin), sondern direkt unser eigenes
 * EconomyManager - damit Käufe/Verkäufe immer exakt mit dem Guthaben
 * übereinstimmen, das Scoreboard/`/eco`/`/pay` anzeigen.
 */
public class GuiListener implements Listener {

    private final SpookyCraftCore plugin;

    public GuiListener(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder topHolder = event.getView().getTopInventory().getHolder();
        if (!(topHolder instanceof MarktHolder holder)) {
            return;
        }
        Player player = (Player) event.getWhoClicked();
        Inventory clickedInventory = event.getClickedInventory();
        ShopManager shopManager = getShopManager();
        if (shopManager == null) return;

        if (holder.getType() == MarktHolder.Type.MAIN) {
            event.setCancelled(true);
            if (clickedInventory == null || clickedInventory.getHolder() != holder) {
                return;
            }
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || clicked.getType() == Material.AIR) {
                return;
            }
            for (ShopCategory category : shopManager.getCategories().values()) {
                if (category.getIcon() != clicked.getType() || event.getSlot() != category.getSlot()) continue;
                GuiManager.openCategory(player, category);
                return;
            }
            return;
        }

        if (holder.getType() == MarktHolder.Type.CATEGORY) {
            event.setCancelled(true);
            ShopCategory category = shopManager.getCategories().get(holder.getCategoryKey());
            if (category == null) return;

            if (clickedInventory != null && clickedInventory.getHolder() == holder) {
                int slot = event.getSlot();
                int backSlot = clickedInventory.getSize() - 5;
                if (slot == backSlot) {
                    GuiManager.openMainMenu(player, shopManager);
                    return;
                }
                List<ShopItem> items = category.getItems();
                if (slot >= 0 && slot < items.size()) {
                    ShopItem item = items.get(slot);
                    int amount = event.isShiftClick() ? 64 : 1;
                    handleBuy(player, item, amount);
                }
            } else if (clickedInventory != null) {
                ItemStack clicked = event.getCurrentItem();
                if (clicked == null || clicked.getType() == Material.AIR) {
                    return;
                }
                ShopItem matchingItem = findItemByMaterial(category, clicked.getType());
                if (matchingItem == null) {
                    player.sendMessage(ChatColor.RED + "Dieses Item kann in dieser Kategorie nicht verkauft werden.");
                    return;
                }
                int amount = event.isShiftClick() ? clicked.getAmount() : 1;
                handleSell(player, clicked, matchingItem, amount);
            }
        }
    }

    private ShopManager getShopManager() {
        var module = plugin.getModuleManager().get("markt");
        return module instanceof MarktModule marktModule ? marktModule.getShopManager() : null;
    }

    private ShopItem findItemByMaterial(ShopCategory category, Material material) {
        for (ShopItem item : category.getItems()) {
            if (item.getMaterial() == material) return item;
        }
        return null;
    }

    private void handleBuy(Player player, ShopItem item, int amount) {
        EconomyModule economyModule = (EconomyModule) plugin.getModuleManager().get("economy");
        if (economyModule == null) return;
        double totalPrice = item.getBuyPrice() * amount;

        if (economyModule.getManager().getBalance(player.getUniqueId()) < totalPrice) {
            player.sendMessage(ChatColor.RED + "Du hast nicht genug Geld! Benötigt: " + totalPrice + "$");
            return;
        }
        if (player.getInventory().firstEmpty() == -1) {
            player.sendMessage(ChatColor.RED + "Dein Inventar ist voll!");
            return;
        }
        if (!economyModule.getManager().withdraw(player.getUniqueId(), totalPrice)) {
            player.sendMessage(ChatColor.RED + "Kauf fehlgeschlagen.");
            return;
        }
        player.getInventory().addItem(new ItemStack(item.getMaterial(), amount));
        player.sendMessage(ChatColor.GREEN + "Gekauft: " + amount + "x " + formatName(item.getMaterial()) + " für " + totalPrice + "$");
    }

    private void handleSell(Player player, ItemStack clickedStack, ShopItem item, int amount) {
        EconomyModule economyModule = (EconomyModule) plugin.getModuleManager().get("economy");
        if (economyModule == null) return;
        amount = Math.min(amount, clickedStack.getAmount());
        double totalPrice = item.getSellPrice() * amount;

        ItemStack toRemove = clickedStack.clone();
        toRemove.setAmount(amount);
        player.getInventory().removeItem(toRemove);
        economyModule.getManager().deposit(player.getUniqueId(), totalPrice);
        player.sendMessage(ChatColor.GREEN + "Verkauft: " + amount + "x " + formatName(item.getMaterial()) + " für " + totalPrice + "$");
    }

    private String formatName(Material material) {
        String[] parts = material.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }
}
