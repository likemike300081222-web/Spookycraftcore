package de.craftsucht.core.bank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

/**
 * /bank - Bankguthaben mit Zinsen und GUI. Vorher ein eigenständiges Plugin
 * (BankSystem, Vault-basiert - "reagiert nicht auf unsere Economy" war
 * genau deswegen, Vault zeigte auf einen anderen Kontostand als unseren
 * eigenen). Jetzt Modul hier, Ein-/Auszahlen läuft direkt über unsere
 * eigene Economy.
 */
public class BankModule implements Module {

    private final SpookyCraftCore plugin;
    private BankManager bankManager;
    private ZinsManager zinsManager;
    private GUIListener guiListener;

    public BankModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "bank";
    }

    @Override
    public void enable() {
        this.bankManager = new BankManager(plugin);
        this.zinsManager = new ZinsManager(plugin, bankManager);
        this.guiListener = new GUIListener(plugin, bankManager);
        Bukkit.getPluginManager().registerEvents(guiListener, plugin);

        BankCommand command = new BankCommand(plugin, bankManager, zinsManager);
        plugin.getCommand("bank").setExecutor(command);
        plugin.getCommand("bank").setTabCompleter(command);
    }

    @Override
    public void disable() {
        if (bankManager != null) bankManager.saveAll();
        if (zinsManager != null) zinsManager.shutdown();
        if (guiListener != null) HandlerList.unregisterAll(guiListener);
    }

    public BankManager getBankManager() {
        return bankManager;
    }
}
