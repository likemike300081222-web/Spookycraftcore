package de.craftsucht.core.markt;

import org.bukkit.Material;

public class ShopItem {
    private final Material material;
    private final double buyPrice;
    private final double sellPrice;

    public ShopItem(Material material, double buyPrice, double sellPrice) {
        this.material = material;
        this.buyPrice = buyPrice;
        this.sellPrice = sellPrice;
    }

    public Material getMaterial() {
        return material;
    }

    public double getBuyPrice() {
        return buyPrice;
    }

    public double getSellPrice() {
        return sellPrice;
    }
}
