package de.craftsucht.core.rank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

/** LuckPerms-style internal rank/permission system: groups, inheritance, prefixes, per-rank permissions. */
public class RankModule implements Module {

    private final SpookyCraftCore plugin;
    private RankManager manager;
    private RankListener listener;

    public RankModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "rank";
    }

    @Override
    public void enable() {
        this.manager = new RankManager(plugin);
        manager.ensureDefaultRank();

        RankCommand command = new RankCommand(plugin, manager);
        plugin.getCommand("rank").setExecutor(command);
        plugin.getCommand("rank").setTabCompleter(command);

        this.listener = new RankListener(plugin, manager);
        Bukkit.getPluginManager().registerEvents(listener, plugin);

        for (var p : Bukkit.getOnlinePlayers()) {
            manager.apply(p);
        }
    }

    @Override
    public void disable() {
        if (listener != null) HandlerList.unregisterAll(listener);
        if (manager != null) {
            for (var p : Bukkit.getOnlinePlayers()) manager.remove(p);
        }
    }

    public RankManager getManager() {
        return manager;
    }
}
