package de.craftsucht.core.itemdb;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

/**
 * Item-Datenbank: /db add|search|see - Items aus der Hand speichern und in
 * einem Nur-Ansicht-GUI durchsuchen/anschauen (nicht entnehmbar). Nutzt die
 * gemeinsame SQLite-Datenbank des Core-Plugins statt einer eigenen.
 */
public class ItemDbModule implements Module {

    private final SpookyCraftCore plugin;
    private ItemDbManager manager;
    private ItemDbGuiListener listener;

    public ItemDbModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "itemdb";
    }

    @Override
    public void enable() {
        this.manager = new ItemDbManager(plugin);

        ItemDbCommand command = new ItemDbCommand(plugin, manager);
        plugin.getCommand("db").setExecutor(command);
        plugin.getCommand("db").setTabCompleter(command);

        this.listener = new ItemDbGuiListener();
        Bukkit.getPluginManager().registerEvents(listener, plugin);
    }

    @Override
    public void disable() {
        if (listener != null) HandlerList.unregisterAll(listener);
    }

    public ItemDbManager getManager() {
        return manager;
    }
}
