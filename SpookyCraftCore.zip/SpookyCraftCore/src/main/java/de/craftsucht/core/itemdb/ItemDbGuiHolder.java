package de.craftsucht.core.itemdb;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.List;

/**
 * Markiert ein Inventar als ItemDB-Ansicht-GUI (read-only).
 * Wird vom ItemDbGuiListener genutzt, um jegliches Entnehmen von Items zu
 * verhindern und Seiten-Buttons (vor/zurück) auszuwerten.
 */
public class ItemDbGuiHolder implements InventoryHolder {

    public static final int PAGE_SIZE = 45; // 5 Reihen à 9 für Items, unterste Reihe für Navigation
    public static final int PREV_SLOT = 45;
    public static final int NEXT_SLOT = 53;
    public static final int INFO_SLOT = 49;

    private final List<DBEntry> entries;
    private final int page;
    private final String title;
    private Inventory inventory;

    public ItemDbGuiHolder(List<DBEntry> entries, int page, String title) {
        this.entries = entries;
        this.page = page;
        this.title = title;
    }

    public List<DBEntry> getEntries() {
        return entries;
    }

    public int getPage() {
        return page;
    }

    public String getTitle() {
        return title;
    }

    public int getMaxPage() {
        return Math.max(0, (entries.size() - 1) / PAGE_SIZE);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
