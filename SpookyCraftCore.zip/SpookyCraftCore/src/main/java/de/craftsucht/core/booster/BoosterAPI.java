package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

/**
 * Öffentliche API, um den Job-Boost eines gehaltenen Items abzufragen.
 * Vorher gehörte das zu einem separaten Plugin (BoosterItemsPlugin), das
 * unser jobs-Modul per Reflection angesprochen hat (softdepend). Jetzt läuft
 * beides im selben Plugin - das jobs-Modul ruft diese Klasse direkt auf,
 * keine Reflection mehr nötig (siehe JobListener).
 */
public final class BoosterAPI {

    private BoosterAPI() {
    }

    public static NamespacedKey keyJob(SpookyCraftCore plugin) {
        return new NamespacedKey(plugin, "booster_job");
    }

    public static NamespacedKey keyMoney(SpookyCraftCore plugin) {
        return new NamespacedKey(plugin, "booster_money");
    }

    public static NamespacedKey keyXp(SpookyCraftCore plugin) {
        return new NamespacedKey(plugin, "booster_xp");
    }

    public static BoosterResult getBoost(SpookyCraftCore plugin, Player player, String jobName) {
        ItemStack mainHand = player.getInventory().getItemInMainHand();
        return getBoost(plugin, mainHand, jobName);
    }

    public static BoosterResult getBoost(SpookyCraftCore plugin, ItemStack item, String jobName) {
        if (item == null || !item.hasItemMeta()) {
            return BoosterResult.none();
        }
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String job = pdc.get(keyJob(plugin), PersistentDataType.STRING);
        if (job == null || !job.equalsIgnoreCase(jobName)) {
            return BoosterResult.none();
        }
        double moneyPercent = pdc.getOrDefault(keyMoney(plugin), PersistentDataType.DOUBLE, 0.0);
        double xpPercent = pdc.getOrDefault(keyXp(plugin), PersistentDataType.DOUBLE, 0.0);
        return new BoosterResult(job, 1.0 + moneyPercent / 100.0, 1.0 + xpPercent / 100.0);
    }

    public record BoosterResult(String job, double moneyMultiplier, double xpMultiplier) {
        public static BoosterResult none() {
            return new BoosterResult(null, 1.0, 1.0);
        }

        public boolean isActive() {
            return job != null;
        }
    }
}
